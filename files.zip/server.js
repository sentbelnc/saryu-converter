const express = require('express');
const multer = require('multer');
const axios = require('axios');
const path = require('path');
const fs = require('fs');

const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.json());

// HTML 파일 서빙
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// 변환 API
app.post('/convert', upload.single('file'), async (req, res) => {
  try {
    const apiKey = process.env.API_KEY;
    const fileBuffer = fs.readFileSync(req.file.path);
    const base64 = fileBuffer.toString('base64');
    const mimeType = req.file.mimetype;

    const response = await axios.post(
      'https://api.anthropic.com/v1/messages',
      {
        model: 'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'document',
              source: { type: 'base64', media_type: mimeType, data: base64 }
            },
            {
              type: 'text',
              text: `당신은 센트비(주식회사 센트비) 사규 문서 변환 전문가입니다.
아래 문서를 센트비 사규 표준 양식으로 완전히 변환해주세요.

【센트비 사규 표준 양식 규칙】

1. 표지 구성
   사규명 (예: 사규 관리 규정)
   주식회사 센트비
   Version X.X

2. 사규내역 표 (표지 다음)
   관리번호 | 사규명 | 기안부서 | 공포일자 | 승인자 | 시행일자

3. 개정이력 표
   버전 | 변경내용 | 제·개정/공포일자 | 시행일자 | 작성자 | 승인자

4. 목차
   제 N 장  [장 제목] ···· N

5. 본문 구조
   - 장 구분: 제 N 장  [장 제목] (가운데 정렬)
   - 조 구분: 제 N 조【제목】
   - 항 번호: ①②③
   - 세부 호: 1. 2. 3.
   - 세부 목: 가. 나. 다.

6. 용어
   - "회사" → "센트비" 또는 "주식회사 센트비"
   - 문체: ~한다, ~된다, ~할 수 있다

【중요】
- 조항 내용(의미)은 절대 바꾸지 마세요. 형식과 구조만 변환하세요.
- 원문의 모든 조항을 빠짐없이 포함하세요.
- 변환된 문서 전체만 출력하고 부연 설명은 쓰지 마세요.`
            }
          ]
        }]
      },
      {
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json'
        }
      }
    );

    // 업로드 파일 삭제
    fs.unlinkSync(req.file.path);

    const result = response.data.content.map(b => b.text || '').join('\n').trim();
    res.json({ result });

  } catch (e) {
    console.error(e.response?.data || e.message);
    res.status(500).json({ error: e.response?.data?.error?.message || e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log('서버 실행 중: ' + PORT));
